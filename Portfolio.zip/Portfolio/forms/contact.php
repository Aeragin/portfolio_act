<?php
$conn = mysqli_connect('localhost', 'root', '', 'contact') or die('Connection failed: ' . mysqli_connect_error());

if (isset($_POST['message'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $subject = mysqli_real_escape_string($conn, $_POST['subject']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);

    $stmt = mysqli_prepare($conn, "INSERT INTO contactme (`name`, `email`, `subject`, `message`) VALUES (?, ?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "ssss", $name, $email, $subject, $message);

    if (mysqli_stmt_execute($stmt)) {
        $message = 'Message Sent Successfully';
    } else {
        $message = 'Failed to send message: ' . mysqli_stmt_error($stmt);
    }
    mysqli_stmt_close($stmt);
}

mysqli_close($conn);
echo $message; // Display the message for debugging purposes
?>

        
          